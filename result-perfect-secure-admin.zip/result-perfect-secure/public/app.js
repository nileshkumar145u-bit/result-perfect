const $ = id => document.getElementById(id);
let csrfToken = "";
let admin = false;
let posts = [];
const escapeHtml = s => String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function request(url, options={}) {
  const headers = {...(options.headers || {})};
  if (options.body && !headers["Content-Type"]) headers["Content-Type"] = "application/json";
  if (options.method && !["GET","HEAD"].includes(options.method.toUpperCase())) headers["X-CSRF-Token"] = csrfToken;
  const response = await fetch(url, {...options, headers, credentials:"same-origin"});
  const data = await response.json().catch(()=>({error:"सर्वर से जवाब नहीं मिला।"}));
  if (!response.ok) throw new Error(data.error || "अनुरोध असफल हुआ।");
  if (data.csrfToken) csrfToken = data.csrfToken;
  return data;
}
async function loadCsrf() { const d = await request("/api/csrf"); csrfToken=d.csrfToken; }
function renderPublicPosts() {
  const box=$("publicPosts"); box.replaceChildren();
  if (!posts.length) { const p=document.createElement("p"); p.textContent="अभी कोई नया अपडेट नहीं है।"; box.append(p); return; }
  posts.forEach(post=>{
    const el=document.createElement("article"); el.className="post";
    el.innerHTML=`<div class="cat">${escapeHtml(post.category)}</div><h3>${escapeHtml(post.title)}</h3><p class="desc">${escapeHtml(post.description)}</p><a href="${escapeHtml(post.url)}" target="_blank" rel="noopener noreferrer">आधिकारिक लिंक खोलें ↗</a>`;
    box.append(el);
  });
}
function renderManagePosts() {
  const box=$("managePosts"); box.replaceChildren();
  posts.forEach(post=>{
    const row=document.createElement("div"); row.className="post"; row.style.marginBottom="8px";
    row.innerHTML=`<b>${escapeHtml(post.title)}</b><p class="desc">${escapeHtml(post.category)}</p>`;
    const edit=document.createElement("button"); edit.textContent="बदलें"; edit.className="secondary"; edit.style.marginRight="8px";
    edit.addEventListener("click",()=>{ $("editId").value=post.id; $("title").value=post.title; $("category").value=post.category; $("url").value=post.url; $("description").value=post.description||""; $("savePost").textContent="बदलाव सेव करें"; $("postForm").scrollIntoView({behavior:"smooth",block:"center"}); });
    const del=document.createElement("button"); del.textContent="हटाएँ"; del.className="danger";
    del.addEventListener("click",async()=>{if(!confirm("क्या यह पोस्ट हटानी है?"))return; try{await request("/api/posts/"+post.id,{method:"DELETE"}); await loadPosts(); $("adminStatus").textContent="पोस्ट हटा दी गई।";}catch(e){$("adminStatus").textContent=e.message;}});
    row.append(edit,del); box.append(row);
  });
}
async function loadPosts() { const d=await request("/api/posts"); posts=d.posts||[]; renderPublicPosts(); if(admin)renderManagePosts(); }
function setAdmin(on, username) {
  admin=on; $("loginBox").hidden=on; $("adminBox").hidden=!on; $("showLogin").hidden=on;
  if(on) $("loggedInAs").textContent="लॉगिन है: "+username;
}
$("showLogin").addEventListener("click",()=>{$("loginBox").hidden=!$("loginBox").hidden;});
$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault();
  try {
    await request("/api/auth/login",{method:"POST",body:JSON.stringify({username:$("username").value,password:$("password").value})});
    $("password").value=""; const s=await request("/api/auth/status"); setAdmin(true,s.username); await loadPosts(); $("adminStatus").textContent="सफलतापूर्वक लॉगिन हो गया।";
  } catch(err) {$("adminStatus").textContent=err.message; $("loginBox").hidden=false;}
});
$("postForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const id=$("editId").value;
  const payload={title:$("title").value.trim(),category:$("category").value,url:$("url").value.trim(),description:$("description").value.trim()};
  try {
    await request(id?"/api/posts/"+id:"/api/posts",{method:id?"PUT":"POST",body:JSON.stringify(payload)});
    $("postForm").reset(); $("editId").value=""; $("savePost").textContent="पोस्ट जोड़ें"; await loadPosts(); $("adminStatus").textContent=id?"पोस्ट अपडेट हो गई।":"नई पोस्ट प्रकाशित हो गई।";
  } catch(err) {$("adminStatus").textContent=err.message;}
});
$("cancelEdit").addEventListener("click",()=>{$("postForm").reset();$("editId").value="";$("savePost").textContent="पोस्ट जोड़ें";});
$("logout").addEventListener("click",async()=>{try{await request("/api/auth/logout",{method:"POST"});setAdmin(false);$("adminStatus").textContent="लॉगआउट हो गया।";await loadCsrf();}catch(e){$("adminStatus").textContent=e.message;}});
$("search").addEventListener("input",()=>{
  const q=$("search").value.toLocaleLowerCase("hi");
  document.querySelectorAll(".items li,.post").forEach(el=>{
    if(el.closest("#admin") || el.closest("#managePosts")) return;
    el.style.display=el.textContent.toLocaleLowerCase("hi").includes(q)?"":"none";
  });
});
$("clear").addEventListener("click",()=>{$("search").value="";$("search").dispatchEvent(new Event("input"));});
(async()=>{try{await loadCsrf(); const s=await request("/api/auth/status"); if(s.authenticated)setAdmin(true,s.username); await loadPosts(); if(s.authenticated)renderManagePosts();}catch(e){$("publicPosts").textContent="पोस्ट लोड नहीं हो सके। सर्वर/डेटाबेस सेटअप जाँचें।";}})();
