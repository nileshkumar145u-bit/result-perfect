require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const pg = require("pg");
const PgSession = require("connect-pg-simple")(session);
const crypto = require("crypto");
const path = require("path");

const { Pool } = pg;
const app = express();
const isProduction = process.env.NODE_ENV === "production";
const port = Number(process.env.PORT || 3000);

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required.");
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) {
  throw new Error("Set ADMIN_USERNAME and ADMIN_PASSWORD in your environment.");
}
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be at least 32 characters.");
}
if (process.env.ADMIN_PASSWORD.length < 14) {
  throw new Error("ADMIN_PASSWORD must be at least 14 characters.");
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: true } : undefined
});

app.disable("x-powered-by");
if (isProduction) app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: isProduction ? [] : null
    }
  }
}));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));

const sessionStore = new PgSession({
  pool,
  tableName: "user_sessions",
  createTableIfMissing: true,
  pruneSessionInterval: 15 * 60
});
app.use(session({
  name: "rp_admin_session",
  store: sessionStore,
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: "lax",
    maxAge: 2 * 60 * 60 * 1000
  }
}));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "बहुत बार लॉगिन कोशिश हुई। 15 मिनट बाद फिर प्रयास करें।" }
});

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin === true) return next();
  return res.status(401).json({ error: "लॉगिन आवश्यक है।" });
}
function validHttpsUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === "https:" && !u.username && !u.password;
  } catch { return false; }
}

// Lightweight session-bound CSRF token. All state-changing endpoints require it.
function ensureCsrf(req, res, next) {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString("hex");
  next();
}
app.use(ensureCsrf);
app.get("/api/csrf", (req, res) => res.json({ csrfToken: req.session.csrfToken }));
function checkCsrf(req, res, next) {
  const supplied = req.get("x-csrf-token") || "";
  if (!req.session.csrfToken || !safeEqual(supplied, req.session.csrfToken)) {
    return res.status(403).json({ error: "सुरक्षा टोकन गलत या समाप्त है। पेज रीफ्रेश करके फिर कोशिश करें।" });
  }
  next();
}

app.get("/api/posts", async (_req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT id, title, category, url, description, created_at FROM posts ORDER BY created_at DESC LIMIT 200"
    );
    res.json({ posts: result.rows });
  } catch (e) { next(e); }
});
app.get("/api/auth/status", (req, res) => {
  res.json({ authenticated: req.session.isAdmin === true, username: req.session.isAdmin ? process.env.ADMIN_USERNAME : null });
});
app.post("/api/auth/login", loginLimiter, checkCsrf, async (req, res, next) => {
  try {
    const username = String(req.body.username || "");
    const password = String(req.body.password || "");
    const usernameOk = safeEqual(username, process.env.ADMIN_USERNAME);
    // Password comparison is constant-time; only one configured admin account is accepted.
    const passwordOk = safeEqual(password, process.env.ADMIN_PASSWORD);
    if (!usernameOk || !passwordOk) {
      return res.status(401).json({ error: "यूज़रनेम या पासवर्ड सही नहीं है।" });
    }
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.isAdmin = true;
      req.session.csrfToken = crypto.randomBytes(32).toString("hex");
      req.session.save(err2 => {
        if (err2) return next(err2);
        res.json({ ok: true, csrfToken: req.session.csrfToken });
      });
    });
  } catch (e) { next(e); }
});
app.post("/api/auth/logout", requireAdmin, checkCsrf, (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("rp_admin_session", { httpOnly: true, secure: isProduction, sameSite: "lax" });
    res.json({ ok: true });
  });
});

app.post("/api/posts", requireAdmin, checkCsrf, async (req, res, next) => {
  try {
    const title = String(req.body.title || "").trim();
    const category = String(req.body.category || "").trim();
    const url = String(req.body.url || "").trim();
    const description = String(req.body.description || "").trim();
    const allowed = ["Result", "Latest Job", "Admit Card", "Online Form", "Important Link"];
    if (!title || title.length > 120) return res.status(400).json({ error: "शीर्षक 1 से 120 अक्षरों का होना चाहिए।" });
    if (!allowed.includes(category)) return res.status(400).json({ error: "कैटेगरी चुनें।" });
    if (!validHttpsUrl(url)) return res.status(400).json({ error: "केवल सही HTTPS लिंक स्वीकार है।" });
    if (description.length > 500) return res.status(400).json({ error: "जानकारी 500 अक्षरों से कम रखें।" });
    const result = await pool.query(
      "INSERT INTO posts (title, category, url, description) VALUES ($1, $2, $3, $4) RETURNING id, title, category, url, description, created_at",
      [title, category, url, description]
    );
    res.status(201).json({ post: result.rows[0] });
  } catch (e) { next(e); }
});
app.put("/api/posts/:id", requireAdmin, checkCsrf, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const title = String(req.body.title || "").trim();
    const category = String(req.body.category || "").trim();
    const url = String(req.body.url || "").trim();
    const description = String(req.body.description || "").trim();
    const allowed = ["Result", "Latest Job", "Admit Card", "Online Form", "Important Link"];
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: "गलत पोस्ट ID।" });
    if (!title || title.length > 120 || !allowed.includes(category) || !validHttpsUrl(url) || description.length > 500) {
      return res.status(400).json({ error: "जानकारी जाँचें। सही शीर्षक, कैटेगरी और HTTPS लिंक जरूरी है।" });
    }
    const result = await pool.query(
      "UPDATE posts SET title=$1, category=$2, url=$3, description=$4 WHERE id=$5 RETURNING id, title, category, url, description, created_at",
      [title, category, url, description, id]
    );
    if (!result.rowCount) return res.status(404).json({ error: "पोस्ट नहीं मिली।" });
    res.json({ post: result.rows[0] });
  } catch (e) { next(e); }
});
app.delete("/api/posts/:id", requireAdmin, checkCsrf, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: "गलत पोस्ट ID।" });
    const result = await pool.query("DELETE FROM posts WHERE id=$1", [id]);
    if (!result.rowCount) return res.status(404).json({ error: "पोस्ट नहीं मिली।" });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "सर्वर में समस्या आई। कृपया बाद में कोशिश करें।" });
});

async function start() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS posts (
      id BIGSERIAL PRIMARY KEY,
      title VARCHAR(120) NOT NULL,
      category VARCHAR(30) NOT NULL,
      url TEXT NOT NULL,
      description VARCHAR(500) NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  app.listen(port, () => console.log(`Result Perfect running on port ${port}`));
}
start().catch(err => { console.error("Startup failed:", err); process.exit(1); });
